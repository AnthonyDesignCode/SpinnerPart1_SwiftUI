//
//  Spinner_SwiftUIApp.swift
//  Spinner_SwiftUI
//
//  Created by Anthony Codes on 22/08/2020.
//

import SwiftUI

@main
struct Spinner_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
